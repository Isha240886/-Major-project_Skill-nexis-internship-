# Nukkad — MERN E-Commerce App

Features: product listing + search, register/login (JWT), cart, checkout, order history, admin dashboard (add/edit/delete products, update order status).

## Run locally
1. **Server:** `cd server && npm install`, copy `.env.example` to `.env`, fill in `MONGO_URI` (MongoDB Atlas), then `npm run dev`.
   On first start it creates sample products and an admin user (`ADMIN_EMAIL` / `ADMIN_PASSWORD`).
2. **Client:** `cd client && npm install`, copy `.env.example` to `.env`, then `npm run dev` (opens on port 5173).

## Deploy
1. **Database:** MongoDB Atlas → create free cluster → Database Access user → Network Access allow `0.0.0.0/0` → copy connection string.
2. **API on Render:** New Web Service → root directory `server` → build `npm install` → start `npm start` → add env vars from `.env.example` (set `CLIENT_URL` to your Vercel URL after step 3).
3. **Client on Vercel/Netlify:** root directory `client` → build `npm run build` → output `dist` → env var `VITE_API_URL` = your Render URL.
   For Netlify add a `_redirects` file in `client/public` containing `/* /index.html 200`; on Vercel add `vercel.json` with a rewrite of `/(.*)` to `/`.

## API
`POST /api/auth/register|login` · `GET /api/products?q=` · `POST/PUT/DELETE /api/products` (admin) · `POST /api/orders` · `GET /api/orders/mine` · `GET/PUT /api/orders` (admin)
