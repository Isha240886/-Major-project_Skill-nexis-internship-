import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import mongoose from 'mongoose';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import { User, Product, Order } from './models.js';

const app = express();
app.use(cors({ origin: process.env.CLIENT_URL || '*' }));
app.use(express.json());

// ---------- helpers ----------
const sign = u => jwt.sign({ id: u._id }, process.env.JWT_SECRET, { expiresIn: '7d' });
const pub = u => ({ name: u.name, isAdmin: u.isAdmin });
const wrap = fn => (req, res) => fn(req, res).catch(e => res.status(400).json({ message: e.message }));

const auth = async (req, res, next) => {
  try {
    const token = req.headers.authorization?.split(' ')[1];
    req.user = await User.findById(jwt.verify(token, process.env.JWT_SECRET).id);
    if (!req.user) throw new Error();
    next();
  } catch {
    res.status(401).json({ message: 'Please log in first' });
  }
};
const admin = (req, res, next) =>
  req.user.isAdmin ? next() : res.status(403).json({ message: 'Admins only' });

// ---------- auth ----------
app.post('/api/auth/register', wrap(async (req, res) => {
  const { name, email, password } = req.body;
  if (!name || !email || !password || password.length < 6) throw new Error('Enter name, email and a password of 6+ characters');
  if (await User.findOne({ email })) throw new Error('This email is already registered');
  const u = await User.create({ name, email, password: await bcrypt.hash(password, 10) });
  res.json({ token: sign(u), user: pub(u) });
}));

app.post('/api/auth/login', wrap(async (req, res) => {
  const u = await User.findOne({ email: req.body.email });
  if (!u || !(await bcrypt.compare(req.body.password || '', u.password))) throw new Error('Wrong email or password');
  res.json({ token: sign(u), user: pub(u) });
}));

// ---------- products ----------
app.get('/api/products', wrap(async (req, res) => {
  const q = req.query.q ? { name: new RegExp(req.query.q.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'i') } : {};
  res.json(await Product.find(q).sort('-createdAt'));
}));
app.post('/api/products', auth, admin, wrap(async (req, res) => res.json(await Product.create(req.body))));
app.put('/api/products/:id', auth, admin, wrap(async (req, res) =>
  res.json(await Product.findByIdAndUpdate(req.params.id, req.body, { new: true }))));
app.delete('/api/products/:id', auth, admin, wrap(async (req, res) => {
  await Product.findByIdAndDelete(req.params.id);
  res.json({ ok: true });
}));

// ---------- orders ----------
app.post('/api/orders', auth, wrap(async (req, res) => {
  const items = [];
  for (const { product, qty } of req.body.items || []) {
    const p = await Product.findById(product);
    if (!p || qty < 1 || p.stock < qty) throw new Error(`${p ? p.name : 'An item'} is out of stock`);
    p.stock -= qty;
    await p.save();
    items.push({ product: p._id, name: p.name, price: p.price, qty });
  }
  if (!items.length) throw new Error('Your cart is empty');
  const total = items.reduce((s, i) => s + i.price * i.qty, 0); // price comes from DB, not the client
  res.json(await Order.create({ user: req.user._id, items, total }));
}));
app.get('/api/orders/mine', auth, wrap(async (req, res) => res.json(await Order.find({ user: req.user._id }).sort('-createdAt'))));
app.get('/api/orders', auth, admin, wrap(async (req, res) => res.json(await Order.find().populate('user', 'name email').sort('-createdAt'))));
app.put('/api/orders/:id', auth, admin, wrap(async (req, res) =>
  res.json(await Order.findByIdAndUpdate(req.params.id, { status: req.body.status }, { new: true }))));

// ---------- start + seed ----------
const seed = async () => {
  const { ADMIN_EMAIL, ADMIN_PASSWORD } = process.env;
  if (ADMIN_EMAIL && !(await User.findOne({ email: ADMIN_EMAIL })))
    await User.create({ name: 'Admin', email: ADMIN_EMAIL, password: await bcrypt.hash(ADMIN_PASSWORD, 10), isAdmin: true });
  if (!(await Product.countDocuments())) {
    const names = [['Canvas Backpack', 1499], ['Steel Water Bottle', 599], ['Wireless Earbuds', 1999], ['Desk Lamp', 899], ['Notebook Set', 349], ['Phone Stand', 299]];
    await Product.insertMany(names.map(([name, price]) => ({
      name, price, stock: 20, description: `${name} — everyday quality at a fair price.`,
      image: `https://picsum.photos/seed/${encodeURIComponent(name)}/400/300`
    })));
  }
};

mongoose.connect(process.env.MONGO_URI)
  .then(seed)
  .then(() => app.listen(process.env.PORT || 5000, () => console.log('API running')))
  .catch(e => { console.error('Startup failed:', e.message); process.exit(1); });
