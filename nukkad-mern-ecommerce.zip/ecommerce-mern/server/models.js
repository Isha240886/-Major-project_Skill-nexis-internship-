import mongoose from 'mongoose';
const { Schema, model } = mongoose;

export const User = model('User', new Schema({
  name: String,
  email: { type: String, unique: true },
  password: String,
  isAdmin: { type: Boolean, default: false }
}));

export const Product = model('Product', new Schema({
  name: String, price: Number, image: String, description: String,
  stock: { type: Number, default: 10 }
}, { timestamps: true }));

export const Order = model('Order', new Schema({
  user: { type: Schema.Types.ObjectId, ref: 'User' },
  items: [{ product: { type: Schema.Types.ObjectId, ref: 'Product' }, name: String, price: Number, qty: Number }],
  total: Number,
  status: { type: String, default: 'Pending' }
}, { timestamps: true }));
