import { useState, useEffect, createContext, useContext } from 'react';
import { Routes, Route, Link, useNavigate } from 'react-router-dom';
import { api } from './api';

const Ctx = createContext();
const useApp = () => useContext(Ctx);
const read = (k) => { try { return JSON.parse(localStorage.getItem(k)); } catch { return null; } };
const rupee = (n) => '₹' + n.toLocaleString('en-IN');

export default function App() {
  const [user, setUser] = useState(read('user'));
  const [cart, setCart] = useState(read('cart') || []);
  useEffect(() => localStorage.setItem('cart', JSON.stringify(cart)), [cart]);

  const login = ({ token, user }) => {
    localStorage.setItem('token', token);
    localStorage.setItem('user', JSON.stringify(user));
    setUser(user);
  };
  const logout = () => { localStorage.removeItem('token'); localStorage.removeItem('user'); setUser(null); };
  const add = (p) => setCart((c) => c.some((i) => i._id === p._id)
    ? c.map((i) => (i._id === p._id ? { ...i, qty: Math.min(i.qty + 1, p.stock) } : i))
    : [...c, { ...p, qty: 1 }]);
  const setQty = (id, qty) => setCart((c) => c.map((i) => (i._id === id ? { ...i, qty } : i)).filter((i) => i.qty > 0));

  return (
    <Ctx.Provider value={{ user, cart, setCart, login, add, setQty }}>
      <header className="nav">
        <Link to="/" className="brand">nukkad</Link>
        <nav>
          <Link to="/cart">Cart ({cart.reduce((s, i) => s + i.qty, 0)})</Link>
          {user && <Link to="/orders">My orders</Link>}
          {user?.isAdmin && <Link to="/admin">Admin</Link>}
          {user ? <button className="link" onClick={logout}>Log out ({user.name})</button> : <Link to="/login">Log in</Link>}
        </nav>
      </header>
      <main>
        <Routes>
          <Route path="/" element={<Products />} />
          <Route path="/cart" element={<Cart />} />
          <Route path="/login" element={<Auth mode="login" />} />
          <Route path="/register" element={<Auth mode="register" />} />
          <Route path="/orders" element={<Orders />} />
          <Route path="/admin" element={<Admin />} />
        </Routes>
      </main>
    </Ctx.Provider>
  );
}

function Products() {
  const { add } = useApp();
  const [list, setList] = useState([]);
  const [q, setQ] = useState('');
  const [err, setErr] = useState('');
  useEffect(() => {
    const t = setTimeout(() => api(`/products?q=${encodeURIComponent(q)}`).then(setList).catch((e) => setErr(e.message)), 300);
    return () => clearTimeout(t);
  }, [q]);

  return (
    <>
      <input className="search" placeholder="Search products" value={q} onChange={(e) => setQ(e.target.value)} />
      {err && <p className="error">{err}</p>}
      {!err && !list.length && <p>No products found. Try a different search.</p>}
      <div className="grid">
        {list.map((p) => (
          <article className="card" key={p._id}>
            <img src={p.image} alt={p.name} />
            <h3>{p.name}</h3>
            <p className="muted">{p.description}</p>
            <div className="row">
              <strong>{rupee(p.price)}</strong>
              <button disabled={p.stock < 1} onClick={() => add(p)}>{p.stock < 1 ? 'Sold out' : 'Add to cart'}</button>
            </div>
          </article>
        ))}
      </div>
    </>
  );
}

function Cart() {
  const { cart, setCart, setQty, user } = useApp();
  const nav = useNavigate();
  const [err, setErr] = useState('');
  const total = cart.reduce((s, i) => s + i.price * i.qty, 0);

  const checkout = async () => {
    if (!user) return nav('/login');
    try {
      await api('/orders', 'POST', { items: cart.map((i) => ({ product: i._id, qty: i.qty })) });
      setCart([]);
      nav('/orders');
    } catch (e) { setErr(e.message); }
  };

  if (!cart.length) return <p>Your cart is empty. <Link to="/">Browse products</Link></p>;
  return (
    <div className="panel">
      {cart.map((i) => (
        <div className="row line" key={i._id}>
          <span>{i.name}</span>
          <span>
            <button className="sm" onClick={() => setQty(i._id, i.qty - 1)}>−</button>
            <b className="qty">{i.qty}</b>
            <button className="sm" disabled={i.qty >= i.stock} onClick={() => setQty(i._id, i.qty + 1)}>+</button>
          </span>
          <strong>{rupee(i.price * i.qty)}</strong>
        </div>
      ))}
      <div className="row line"><h3>Total</h3><h3>{rupee(total)}</h3></div>
      {err && <p className="error">{err}</p>}
      <button onClick={checkout}>{user ? 'Place order' : 'Log in to order'}</button>
    </div>
  );
}

function Auth({ mode }) {
  const { login } = useApp();
  const nav = useNavigate();
  const [f, setF] = useState({ name: '', email: '', password: '' });
  const [err, setErr] = useState('');
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });

  const submit = async (e) => {
    e.preventDefault();
    try { login(await api(`/auth/${mode}`, 'POST', f)); nav('/'); } catch (x) { setErr(x.message); }
  };

  return (
    <form className="panel narrow" onSubmit={submit}>
      <h2>{mode === 'login' ? 'Log in' : 'Create account'}</h2>
      {mode === 'register' && <input placeholder="Name" value={f.name} onChange={set('name')} />}
      <input type="email" placeholder="Email" value={f.email} onChange={set('email')} />
      <input type="password" placeholder="Password (6+ characters)" value={f.password} onChange={set('password')} />
      {err && <p className="error">{err}</p>}
      <button>{mode === 'login' ? 'Log in' : 'Sign up'}</button>
      <p className="muted">
        {mode === 'login' ? <>New here? <Link to="/register">Create an account</Link></> : <>Have an account? <Link to="/login">Log in</Link></>}
      </p>
    </form>
  );
}

function Orders() {
  const [orders, setOrders] = useState([]);
  const [err, setErr] = useState('');
  useEffect(() => { api('/orders/mine').then(setOrders).catch((e) => setErr(e.message)); }, []);
  if (err) return <p className="error">{err}</p>;
  if (!orders.length) return <p>No orders yet. <Link to="/">Start shopping</Link></p>;
  return orders.map((o) => (
    <div className="panel" key={o._id}>
      <div className="row"><b>{new Date(o.createdAt).toLocaleDateString('en-IN')}</b><span className="tag">{o.status}</span></div>
      {o.items.map((i) => <p key={i._id} className="muted">{i.qty} × {i.name}</p>)}
      <strong>{rupee(o.total)}</strong>
    </div>
  ));
}

const blank = { name: '', price: '', image: '', description: '', stock: 10 };

function Admin() {
  const { user } = useApp();
  const [products, setProducts] = useState([]);
  const [orders, setOrders] = useState([]);
  const [form, setForm] = useState(blank);
  const [err, setErr] = useState('');
  const load = () => Promise.all([api('/products'), api('/orders')]).then(([p, o]) => { setProducts(p); setOrders(o); }).catch((e) => setErr(e.message));
  useEffect(() => { if (user?.isAdmin) load(); }, []);

  if (!user?.isAdmin) return <p className="error">This page is for admins only.</p>;
  const set = (k) => (e) => setForm({ ...form, [k]: e.target.value });

  const save = async (e) => {
    e.preventDefault();
    const body = { ...form, price: Number(form.price), stock: Number(form.stock) };
    try {
      await (form._id ? api(`/products/${form._id}`, 'PUT', body) : api('/products', 'POST', body));
      setForm(blank); load();
    } catch (x) { setErr(x.message); }
  };
  const remove = async (id) => { if (confirm('Delete this product?')) { await api(`/products/${id}`, 'DELETE'); load(); } };
  const status = async (id, s) => { await api(`/orders/${id}`, 'PUT', { status: s }); load(); };

  return (
    <>
      <form className="panel" onSubmit={save}>
        <h2>{form._id ? 'Edit product' : 'Add product'}</h2>
        <input placeholder="Name" value={form.name} onChange={set('name')} required />
        <input type="number" placeholder="Price (₹)" value={form.price} onChange={set('price')} required />
        <input placeholder="Image URL" value={form.image} onChange={set('image')} />
        <input placeholder="Description" value={form.description} onChange={set('description')} />
        <input type="number" placeholder="Stock" value={form.stock} onChange={set('stock')} />
        {err && <p className="error">{err}</p>}
        <button>{form._id ? 'Save changes' : 'Add product'}</button>
      </form>

      <h2>Products</h2>
      {products.map((p) => (
        <div className="row line" key={p._id}>
          <span>{p.name} · {rupee(p.price)} · {p.stock} in stock</span>
          <span><button className="sm" onClick={() => setForm(p)}>Edit</button> <button className="sm danger" onClick={() => remove(p._id)}>Delete</button></span>
        </div>
      ))}

      <h2>Orders</h2>
      {orders.map((o) => (
        <div className="row line" key={o._id}>
          <span>{o.user?.name} · {rupee(o.total)}</span>
          <select value={o.status} onChange={(e) => status(o._id, e.target.value)}>
            {['Pending', 'Shipped', 'Delivered', 'Cancelled'].map((s) => <option key={s}>{s}</option>)}
          </select>
        </div>
      ))}
    </>
  );
}
